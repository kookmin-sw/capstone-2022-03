module.exports = {
    mongoURI: 'mongodb+srv://SangYun:aa970922@kook.9qnm0.mongodb.net/userInfo?retryWrites=true&w=majority',
}