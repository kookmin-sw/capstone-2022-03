if (process.env.NODE_ENV == 'production') {
    // console.log(String(process.env.NODE_ENV)); debug
    module.exports = require('./prod');
} else {
    // console.log(String(process.env.NODE_ENV)); debug
    module.exports = require('./dev');
}