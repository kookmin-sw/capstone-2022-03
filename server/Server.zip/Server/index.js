const express = require('express')
const app = express()
const port = 7000
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { User } = require("./model/User.js");
const { Club } = require("./model/Club.js");
const config = require("./config/key");
//application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

//application/json
app.use(bodyParser.json());
app.use(cookieParser());

const mongoose = require('mongoose')
mongoose.connect(config.mongoURI)
  .then(() => console.log('mongoDB Connected...'))
  .catch(err => console.log(err))


app.get('/', (req, res) => {
  res.send('Hello capstone!')
})

//회원가입 파트
app.post('/register', (req, res) => {
  //회원가입 할때 필요한 정보들을 client에서 가져오면 그것들을 database에 넣어준다.
  const user = new User(req.body)

  //비밀번호의 경우 암호화 필요, 이때 mongoose의 기능이용, 따라서 User.js에서 암호화 작업 진행후
  user.save((err, userInfo) => {
    if (err) return res.json({ success: false, err })
    return res.status(200).json({
      success: true
    })
  })

})

//로그인 파트
app.post('/login', (req, res) => {
  // 요청된 이메일을 데이터베이스에서 있는지 찾는다.
  User.findOne({ email: req.body.email }, (err, user) => {
    if (!user) {
      return res.json({
        loginSuccess: false,
        message: "제공된 이메일에 해당하는 유저가 없습니다!"
      })
    }
    // 요청된 이메일이 데이터베이스에 있다면, 비밀번호가 맞는 비밀번호인지 확인.
    user.comparePassword(req.body.password, (err, isMatch) => {
      if (!isMatch)
        return res.json({ loginSuccess: false, message: "비밀번호가 틀렸습니다." })
      // 비밀번호 까지 맞다면 토큰을 생성하기.
      user.generateToken((err, user) => {
        if (err) return res.status(400).send(err);

        console.log('user joined club : ', user.joined_club);

        var data = {};
        const find_data = async function () {
          for (let i of user.joined_club) {
            await Club.findOne({ _id: i })
              .then((result) => {
                data[i] = result;
              })
            // { _id: i },
            // function (err, success) {
            //   if (!success) {
            //     return res.json({
            //       isFound: false
            //     })
            //   }
            // }).then((res) => {
            //   console.log(res);
            //   data.i = res;
            // });
          }
        }

        find_data().then(() => {
          console.log(data)
          res.cookie("x_auth", user.token)
            .status(200)
            .json({ loginSuccess: true, userId: user._id, name: user.name, joined_club_data: data }) //수정한 부분
        });
        // find_data().then((result) => { console.log(result) })
        //토큰을 저장한다. 어디에? 쿠키에 저장
        // res.cookie("x_auth", user.token)
        //   .status(200)
        //   .json({ loginSuccess: true, userId: user._id, name: user.name, joined_club: user.joined_club }) //수정한 부분 
      })
      console.log(user._id, user.name, "님이 로그인 하였습니다.")
    })
  })
})

// 모임 생성 파트
// 프론트에서 보내주어야 하는 형식은 아래와 같다.
// {
//   "club_title": "국민대 밴드동아리",
//   "club_id": "1234",
//   "club_constructor": "김상윤",
//   "club_balance": 300000,
//   "joined_user" : [ "user_object id1", "user_object id3", "user_object id2"],
// "receipt" : [{ 
//   "payment_place" : "주경야돈", 
//   "payment_cost" : 100000, 
//   "payment_date" : "2022-04-01", 
//   "payment_item" : [
//       { "item_name" : "소주", 
//       "item_cost" : 3000}, 
//       { "item_name" : "맥주",
//       "item_cost" : 4000}]
// }]      
// }
app.post('/club_register', (req, res) => {
  const club = new Club(req.body);
  console.log(club._id);
  club.save((err, clubInfo) => {
    if (err) return res.json({ success: false, err })
    return res.status(200).json({
      success: true
    })
  })
})

// 메인화면 파트
// 프론트에서 로그인 하면
// 메인화면에서 특정 모임접속
// 프론트에서 보내주어야 하는 형식은 아래와 같다.
// {
// 	"club_id" : "62749a7316b9efe579edaadc"
// }
app.post('/gotoClub', (req, res) => {
  Club.findOne(
    { _id: req.body.club_id }, (err, isMatch) => {
      if (!isMatch) {
        return res.json({
          gotoClub: false,
          message: "제공된 club_id에 해당하는 모임이 없습니다!"
        })
      } else {
        return res.json({
          gotoClub: true,
          message: "해당 club으로 이동이 완료되었습니다."
        })
      }
    })
})

// 모임에 접속후 영수증 추가
// 프론트에서 보내주어야 하는형식은 아래와 같다. club
// {
// 	"user_id" : "62748e77edb2969ea8391090",
// 	"receipt" : 
// 	{ 
//    "user_id" : "626df2e066f10187cadd0311"
// 		"payment_place" : "스터디카페", 
// 		"payment_cost" : 50000, 
// 		"payment_date" : "2022-04-02", 
// 		"payment_item" : [
// 				{ "item_name" : "자리값", 
// 				"item_cost" : 3000}, 
// 				{ "item_name" : "커피값",
// 				"item_cost" : 4000}
// 				]
// 	}
// }
app.post('/add_receipt', (req, res) => {
  Club.findOneAndUpdate(
    { _id: req.body.club_id }, { $push: { receipt: req.body.receipt } }, (err, isPushed) => {
      console.log(req.body.receipt);
      if (!isPushed) {
        return res.json({
          isPushed: false,
          message: "영수증 저장에 실패하였습니다."
        })
      } else {
        return res.json({
          isPushed: true,
          message: "영수증 저장에 성공하였습니다."
        })
      }
    }
  )
})

// 모임 참가 파트
// 클라이언트에서 모임id와 유저id 기반으로 모임에 참가 user의 objectid와 club의 objectid 기반으로 탐색하여 저장
app.post('/join_club', (req, res) => {
  Club.findOneAndUpdate(
    { _id: req.body.club_id }, { $push: { joined_user: req.body.user_id } }, (err, isPushed_1) => {
      if (!isPushed_1) {
        return res.json({
          isPushed_1: false,
          message: "모임 참가에 실패하였습니다."
        })
      } else {
        User.findOneAndUpdate(
          { _id: req.body.user_id }, { $push: { joined_club: req.body.club_id } }, (err, isPushed_2) => {
            if (!isPushed_2) {
              return res.json({
                isPushed_2: false,
                message: "모임 참가에 실패하였습니다."
              })
            } else {
              return res.json
                ({
                  success: true,
                  message: "모임 참가에 성공하였습니다."
                })
            }
          }
        )
      }
    }
  )
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
